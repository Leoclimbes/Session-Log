# Block 1 log

A one-page training log for the 6-week strength block (Oct 27 – Dec 6, 2026).
Log your pre- and post-session scores and notes for each training day, then see
every number plotted on the Charts tab.

## Deploy to Vercel

Option A — Vercel CLI
1. Install Node.js if you don't have it.
2. In this folder run: `npx vercel`
3. Accept the defaults. Run `npx vercel --prod` to publish the live URL.

Option B — GitHub
1. Put this folder in a new GitHub repo.
2. On vercel.com, click Add New → Project and import the repo.
3. Framework preset: Other. No build command, no output directory. Deploy.

## Notes
- Data is saved in the browser on the device you use. It does not sync between
  your phone and computer, so pick one device to log on, or use Export/Import
  on the Data tab to move it.
- Export a backup every week or so.
- On iPhone: open the site in Safari, Share → Add to Home Screen, and it opens
  like an app.
- To change the start date or day types, edit `START` and `TYPES` at the top of
  the script in index.html.
